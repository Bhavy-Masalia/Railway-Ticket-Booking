# Railway-Ticket-Management
Run this command in terminal
npm install

Run this second command in terminal
pip install flask torch mysql-connector-python jinja2

For running this project create .env file and write your password for 
Gmail third party password 

Create database and add the data using the trains_data

See port 5000 on your browser application will run successfully
Note > Application will not run properly in your PC beacuse it requires some .env dependencies that is secret information.
# Railway-Management

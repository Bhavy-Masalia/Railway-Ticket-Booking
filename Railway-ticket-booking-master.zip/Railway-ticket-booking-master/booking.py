# # from_destination = ['suart', 'vadodara', 'mumbai', 'delhi', 'jaipur']
# # to_destination = ['suart', 'vadodara', 'mumbai', 'delhi', 'jaipur']
my_class = ['ECONOMY', 'BUSINESS', 'FIRST']
